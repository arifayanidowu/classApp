<?php

	$config = [
		'dbhost' => 'localhost',
		'dbuser' => 'root',
		'dbpass' => 'boss123',
		'dbname' => 'store'

	];

?>